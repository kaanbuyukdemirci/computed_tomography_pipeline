# Info
This repository is the implementation of the given flowchart (red blocks are marked for other purposes, it doesn't indicate any error or missing part):
![Flowchart](CT&#32;Scan&#32;Workflow.png "CT Scan Workflow")

I used a sample from the dataset "SPHNQA4IQI" on [here](https://www.cancerimagingarchive.net/nbia-search/?CollectionCriteria=LIDC-IDRI).