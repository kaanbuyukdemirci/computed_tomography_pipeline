# Info
This repository is the implementation of the given flowchart (red blocks are marked for other purposes, it doesn't indicate any error or missing part):
![Flowchart](CT&#32;Scan&#32;Workflow.png "CT Scan Workflow")

The repository is not yet complete. All the parts in the flowchart are implemented, but this library as it is now is not that useful. I will add new features for machine learning, control of real motors, and control of real xray emitters.
I used a sample from the dataset "SPHNQA4IQI" on [here](https://www.cancerimagingarchive.net/nbia-search/?CollectionCriteria=LIDC-IDRI).